# Do not import any additional 3rd party external libraries as they will not
# be available to AutoLab and are not needed (or allowed)

import numpy as np


class Conv1D():
    def __init__(self, in_channel, out_channel, kernel_size, stride,
                 weight_init_fn=None, bias_init_fn=None):
        # Do not modify this method
        self.in_channel = in_channel
        self.out_channel = out_channel
        self.kernel_size = kernel_size
        self.stride = stride

        if weight_init_fn is None:
            self.W = np.random.normal(0, 1.0, (out_channel, in_channel, kernel_size))
        else: 
            self.W = weight_init_fn(out_channel, in_channel, kernel_size)
        
        if bias_init_fn is None:
            self.b = np.zeros(out_channel)
        else:
            self.b = bias_init_fn(out_channel)

        self.dW = np.zeros(self.W.shape)
        self.db = np.zeros(self.b.shape)
        self.x = None
        self.out = None
        self.dx = None

    def __call__(self, x):
        return self.forward(x)

    def forward(self, x):
        """
        Argument:
            x (np.array): (batch_size, in_channel, input_size)
        Return:
            out (np.array): (batch_size, out_channel, output_size)
        """
        #print(self.in_channel,self.out_channel,self.kernel_size,self.stride)
        self.x = x
        self.out_size = ((self.x.shape[2] - 1*(self.kernel_size - 1) -1) // self.stride) + 1
        self.out = np.zeros((self.x.shape[0],self.out_channel,self.out_size))

        p = 0
        for j in range(self.out_size):
    
            self.out[:,:,j] = np.tensordot(self.x[:,:,p:p+self.kernel_size],self.W, axes = ([1,2],[1,2])) + self.b
            p = p + self.stride

        """for m in range(self.out.shape[0]):
            for f in range(self.W.shape[0]):
                for c in range(self.W.shape[1]):
                    p = 0
                    for i in range(self.out.shape[2]):
                    
                        self.out[m,f,i] = self.out[m,f,i] + np.sum(x[m,c,p:p+self.kernel_size]*self.W[f,c,:])
                            
                        p = p + self.stride
                self.out[m,f,:] = self.out[m,f,:] + self.b[f]"""

        
        return self.out



    def backward(self, delta):
        """
        Argument:
            delta (np.array): (batch_size, out_channel, output_size)
        Return:
            dx (np.array): (batch_size, in_channel, input_size)
        """
        self.dx = np.zeros(self.x.shape)
        
        q = 0
        for j in range(delta.shape[2]):
            self.dW = self.dW + np.tensordot(delta[:,:,j],self.x[:,:,q:q+self.kernel_size], axes = ([0],[0]))
            self.dx[:,:,q:q+self.kernel_size] = self.dx[:,:,q:q+self.kernel_size] + np.tensordot(delta[:,:,j],self.W, axes = ([1],[0]))
            q = q + self.stride
    
        self.db = np.sum(np.sum(delta,axis=0),axis=1)

        
        return self.dx


class Flatten():
    def __call__(self, x):
        return self.forward(x)

    def forward(self, x):
        """
        Argument:
            x (np.array): (batch_size, in_channel, in_width)
        Return:
            out (np.array): (batch_size, in_channel * in width)
        """
        self.b, self.c, self.w = x.shape
    
        return x.reshape(self.b,-1)

    def backward(self, delta):
        """
        Argument:
            delta (np.array): (batch size, in channel * in width)
        Return:
            dx (np.array): (batch size, in channel, in width)
        """
        return delta.reshape(self.b,self.c,self.w)
